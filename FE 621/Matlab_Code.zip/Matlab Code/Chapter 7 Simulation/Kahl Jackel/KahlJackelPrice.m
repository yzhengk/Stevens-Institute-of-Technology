function [S V F SimPrice] = KahlJackelPrice(scheme,negvar,params,PutCall,S0,K,Mat,r,q,T,N);

% Heston Call or Put price using Kahl-Jackel IJK or Pathwise schemes
% INPUTS
%   scheme = 'IJK' IJK scheme, 'PW' pathwise scheme, 'B' Balanced scheme
%   negvar = 'R' Reflection or 'T' Truncation of negative variances
%   params = Heston parameters
%   PutCall = 'C' for Call option, 'P' for put
%   S0  = Spot Price
%   K = Strike price
%   Mat = Maturity
%   r = risk free rate
%   q = dividend yield
%   T   = Number of time steps
%   N   = Number of stock price paths
%   alpha = weight for implicit-explicit scheme
% OUTPUTS
%   S = Vector of simulated stock prices
%   V = Vector of simulated variances
%   F = Matrix of overriden negative variances
%   SimPrice = option price by simulation


% Heston parameters
kappa = params(1);
theta = params(2);
sigma = params(3);
v0    = params(4);
rho   = params(5);
lambda = params(6);

% Obtain the simulated stock price and simulated variance
[S V F] = KahlJackelSim(scheme,negvar,params,S0,Mat,r,q,T,N);

% Terminal stock prices
ST = S(end,:);

% Payoff vectors
if strcmp(PutCall,'C')
	Payoff = max(ST - K,0);
elseif strcmp(PutCall,'P')
	Payoff = max(K - ST,0);
end
	
% Simulated price
SimPrice = exp(-r*Mat)*mean(Payoff);
